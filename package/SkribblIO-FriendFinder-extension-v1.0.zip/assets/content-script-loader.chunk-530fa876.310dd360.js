(function () {
  'use strict';

  (async () => {
    await import(
      /* @vite-ignore */
      chrome.runtime.getURL("assets/chunk-530fa876.js")
    );
  })().catch(console.error);

})();
