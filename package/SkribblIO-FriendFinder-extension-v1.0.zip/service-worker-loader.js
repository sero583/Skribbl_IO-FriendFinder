import './assets/chunk-f4115101.js';
